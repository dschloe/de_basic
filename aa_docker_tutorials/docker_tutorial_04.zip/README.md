# 실행방법
- run_all.sh 파일 권한 부여 
```
sudo chmod +x run_all.sh
```

- 실행
```
./run_all.sh
```